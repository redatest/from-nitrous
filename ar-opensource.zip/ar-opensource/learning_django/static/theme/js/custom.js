jQuery( function($) {
    $("a.hint").tooltip();

    $(".hintbox").popover();
    $(".hintbox1").popover();
});

/* Start Carousel Pagination */
$(document).ready(
    function() {
        $('.carousel[id]').each(
            function() {
                var html = '<div class="carousel-nav" data-target="' + $(this).attr('id') + '"><ul>';

                for(var i = 0; i < $(this).find('.item').size(); i ++) {
                    html += '<li><a';
                    if(i == 0) {
                        html += ' class="active"';
                    }

                    html += ' href="#">â€¢</a></li>';
                }

                html += '</ul></li>';
                $(this).append(html);
                $('.carousel-control.left[href="#' + $(this).attr('id') + '"]').hide();
            }
        ).bind('slid',
            function(e) {
                var nav = $('.carousel-nav[data-target="' + $(this).attr('id') + '"] ul');
                var index = $(this).find('.item.active').index();
                var item = nav.find('li').get(index);

                nav.find('li a.active').removeClass('active');
                $(item).find('a').addClass('active');

                if(index == 0) {
                    $('.carousel-control.left[href="#' + $(this).attr('id') + '"]').fadeOut();
                } else {
                    $('.carousel-control.left[href="#' + $(this).attr('id') + '"]').fadeIn();
                }

                if(index == nav.find('li').size() - 1) {
                    $('.carousel-control.right[href="#' + $(this).attr('id') + '"]').fadeOut();
                } else {
                    $('.carousel-control.right[href="#' + $(this).attr('id') + '"]').fadeIn();
                }
            }
        );

        $('.carousel-nav a').bind('click',
            function(e) {
                var index = $(this).parent().index();
                var carousel = $('#' + $(this).closest('.carousel-nav').attr('data-target'));

                carousel.carousel(index);
                e.preventDefault();
            }
        );
    }
);
/* End Carousel Pagination */

/* Start Filterable Quicksand Gallery */
$(document).ready(function(){

    var items = $('#stage li'),
        itemsByTags = {};

    // Looping though all the li items:

    items.each(function(i){
        var elem = $(this),
            tags = elem.data('tags').split(',');

        // Adding a data-id attribute. Required by the Quicksand plugin:
        elem.attr('data-id',i);

        $.each(tags,function(key,value){

            // Removing extra whitespace:
            value = $.trim(value);

            if(!(value in itemsByTags)){
                // Create an empty array to hold this item:
                itemsByTags[value] = [];
            }

            // Each item is added to one array per tag:
            itemsByTags[value].push(elem);
        });

    });

    function createList(text,items){

        // This is a helper function that takes the
        // text of a menu button and array of li items

        // Creating an empty unordered list:
        var ul = $('<ul>',{'class':'hidden'});

        $.each(items,function(){
            // Creating a copy of each li item
            // and adding it to the list:

            $(this).clone().appendTo(ul);
        });

        ul.appendTo('#container');

        // Creating a menu item. The unordered list is added
        // as a data parameter (available via .data('list')):

        var a = $('<a>',{
            html: text,
            href:'#',
            data: {list:ul}
        }).appendTo('#filter');
    }

// Creating the "Everything" option in the menu:
    createList('Everything',items);

// Looping though the arrays in itemsByTags:
    $.each(itemsByTags,function(k,v){
        createList(k,v);
    });

    $('#filter a').live('click',function(e){
        var link = $(this);

        link.addClass('active').siblings().removeClass('active');

        // Using the Quicksand plugin to animate the li items.
        // It uses data('list') defined by our createList function:

        $('#stage').quicksand(link.data('list').find('li'));
        e.preventDefault();
    });

// Selecting the first menu item by default:
    $('#filter a:first').click();



}); /* End document ready */
/* End Filterable Quicksand Gallery */

